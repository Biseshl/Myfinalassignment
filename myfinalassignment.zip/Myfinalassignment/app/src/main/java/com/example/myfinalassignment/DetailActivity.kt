package com.example.myfinalassignment

class DetailActivity {
}